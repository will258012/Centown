删除“world/mtr/minecraft/overworld/”中的“signal blocks”文件夹，然后将其解压到相应的目录中！
Delete the "signal-blocks" folder in "world/mtr/minecraft/overworld/", and then extract it to the corresponding directory!